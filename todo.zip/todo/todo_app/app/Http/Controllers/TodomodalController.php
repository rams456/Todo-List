<?php

namespace App\Http\Controllers;

use App\Models\todomodal;
use Illuminate\Http\Request;

class TodomodalController extends Controller
{
    public function index()
    {
        return view('index');
    }

    // public function create()
    // {
    //     //
    // }

    public function store(Request $request)
    {
        $todomodal=new todomodal;
        $todomodal->category_id=$request->get('title_name');
        $todomodal->name=$request->get('list_name');
        $todomodal->save();

        return redirect('show');

    }

    public function show(todomodal $todomodal)
    {
        $show_data=todomodal::all();
        return view('show',['show_data_key'=>$show_data]);
    }

    public function edit(todomodal $todomodal)
    {
        //
    }

    public function update(Request $request, todomodal $todomodal)
    {
        //
    }

    public function destroy(todomodal $todomodal,$id)
    {
        $get_id=todomodal::find($id);
        $get_id->delete();
        return redirect('/show');
    }
}
