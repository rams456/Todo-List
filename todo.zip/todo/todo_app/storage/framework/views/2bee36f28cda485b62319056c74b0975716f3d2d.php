<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style type="text/css">
		.container
		{

		}
		.container button
		{
			border: none;
			padding: 1vh 2vw;
			border-radius: 1vh;
			background: #2196f3;
			margin: 0vh 1vw;
			transition: 0.9s;
			color: whitesmoke;
		}
		.container button:hover
		{
			background: #42a5f5;
		}
		.container a
		{
			text-decoration: none;
			border: none;
			padding: 1.3vh 2vw;
			border-radius: 1vh;
			background: #2196f3;
			transition: 0.9s;
			color: whitesmoke;
		}
		.text_field
		{
			display: none;
		}
		.text_field label
		{
			margin: 0vh 1vw;
		}
		
	</style>
	<title></title>
</head>
<body>
	<div class="container">
		<h1 class="text-center">Add Todo List Here</h1>
		<button  onclick="show_field()">Add List Item</button>
		<a href="show">Show To Do List</a>
		<form class="mt-3" action="/store" method="post">
			<?php echo csrf_field(); ?>
			<div class="text_field">
				<label>
					<input type="text" placeholder="Title" class="form-control" name="title_name">
				</label>
				<label>
					<input type="text" placeholder="Todo list" class="form-control" name="list_name">
				</label>
				<label>
					<input type="submit" value="Create" class="btn btn-success" name="insert">
				</label>
			</div>
		</form>
	</div>

	<script type="text/javascript">
		function show_field()
		{
			document.querySelector(".text_field").style.display = "flex";
		}
	</script>
</body>
</html><?php /**PATH D:\todo\todo_app\resources\views/index.blade.php ENDPATH**/ ?>