<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style type="text/css">
		.container
		{

		}
		.container>a
		{
			text-decoration: none;
			border: none;
			padding: 1vh 2vw;
			border-radius: 1vh;
			background: #2196f3;
			transition: 0.9s;
			color: whitesmoke;
		}
		.select_box
		{
			padding: 1vh 2vw;
			border: 1px solid #f2f2f2;
			outline: none;
		}
	</style>
	<title></title>
</head>
<body>
	<div class="container">
		<table class="table table-bordered shadow text-center table-striped">
			<h1 class="text-center mb-5">To Do List Here</h1>
			<tr>
				<th>Id</th>
				<td>List Name</td>
				<td>Category Name</td>
				<td>Delete List</td>
			</tr>
			@foreach($show_data_key as $show)
			<tr>
				<td>{{$show->id}}</td>
				<td>{{$show->name}}</td>
				<td>{{$show->category_id}}</td>
				<td><a href="/delete/{{$show->id}}" class="btn btn-danger">Delete</a></td>
			</tr>
			@endforeach
		</table>	
		<a href="/">Add List</a>
	</div>

	<div class="container mt-5">
		<h3>Select Option</h3>
		<select class="select_box">
			@foreach($show_data_key as $show)
			<option>{{$show->category_id}}</option>
			@endforeach
		</select>
	</div>

</body>
</html>